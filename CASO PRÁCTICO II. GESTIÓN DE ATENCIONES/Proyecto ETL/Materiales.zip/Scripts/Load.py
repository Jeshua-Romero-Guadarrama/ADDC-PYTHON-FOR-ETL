import polars as pl
from Scripts.Conexion import get_connection, close_connection
import io


def InsertDimToPostgreSQL(data: pl.DataFrame, nombreTabla: str) -> None:

    """
    Este método le permitirá cargar los datos hacia las tablas de dimensiones.

    Recibe como parámetro el dataframe con la data que se cargará y la tabla sobre
    la cual se cargarán los datos.

    Recuerda que este método debe permitir cargar los datos sobre columnas específicas, es decir,
    puede que una tabla tenga 05 columnas, pero el dataframe solo tenga 04 columnas, entonces
    se deberá cargar cada columna del dataframe sobre su correspondiente columna en la tabla de postgresql

    Revise el video la clase para más ayuda.
    
    """


def InsertFactToPostgreSQL(data: pl.DataFrame, nombreTabla: str) -> None:

    """
    Este método le permitirá cargar los datos hacia la tabla de hechos FactAtenciones.

    Recibe como parámetro el dataframe con la data que se cargará y la tabla sobre
    la cual se cargarán los datos.

    Como el Dataframe de entrada cuenta con todas las columnas que se cargarán,
    no se requiere que se especifiqen las columnas durante la carga de datos

    Revise el video la clase para más ayuda.
    
    """
