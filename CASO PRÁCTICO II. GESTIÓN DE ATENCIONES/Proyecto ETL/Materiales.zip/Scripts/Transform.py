import polars as pl 

def RenameColumns(data: pl.DataFrame, mydict: dict) -> pl.DataFrame:

    '''
    este método tiene como parámetro el dataframe con los datos, y el diccionario de datos
    que contiene el nombre actual y el nombre por el cual se cambiarán las columnas

    El método retorna el dataframe con el nombre de las columnas cambiadas

    '''

def SplitByDelimiter(data: pl.DataFrame, columna: str) -> pl.DataFrame:

    '''
    este método tiene como parámetro el dataframe con los datos, y el nombre de la columna
    sobre la cual se aplicará la operación necesaria para dividir la columna usando
    como delimitador " - ".

    El método retorna el dataframe transformado

    '''


def CreateDimension(data: pl.DataFrame, *args):

    """
    Recibe como entrada un dataframe y las columnas que se desean seleccionar
    luego aplica la eliminación de duplicados usando como referencia la primera
    columna de los datos pasados por parámetro.

    Retorna el dataframe transformado  
    
    """


def CreateFactTable(Atenciones: pl.DataFrame, Proveedor: pl.DataFrame, Estado: pl.DataFrame, TipoAtencion: pl.DataFrame) -> pl.DataFrame:
    
    """
    Recibe como parámetro los datframes que se combinarán, de este dataframe combinado se seleccionan
    solo las columnas que se usarán para cargar a la tabla tala de hechos.

    El método retorna el dataframe consolidado.
    """