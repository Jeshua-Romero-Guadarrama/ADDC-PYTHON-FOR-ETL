import psycopg2
from dotenv import load_dotenv
import os 

load_dotenv(".env")

host = os.getenv('HOST')
dbname = os.getenv('DB_NAME')
user = os.getenv('USER')
password = os.getenv('PASSWORD')

def get_connection():

    """
        este método debe crear una conexión con la base de datos Atenciones y retornar la conexión creada
    """


def close_connection(conn: psycopg2):
    """
        este método recibe como parámetro una conexión y lo que hace es
        cerrar esa conexión. No retorna nada como resultado
    """

