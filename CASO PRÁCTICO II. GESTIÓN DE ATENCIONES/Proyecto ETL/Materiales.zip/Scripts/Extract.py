import polars as pl
from Scripts.Conexion import get_connection, close_connection
from pathlib import Path



def ImportDataFromExcel(filepath: str, sheet : str = 'Hoja1') -> pl.DataFrame:

    """
        este método recibe como entrada la ruta del libro de excel atenciones y la hoja de la cual extraerá los datos
        Recuerda que se deberá indicar el tipo de dato fecha para las columnas: Fecha Creacion y Fecha Cierre.

        Este método deberá validar que la variable filepath es un archivo, caso contrario retornará None.

        El metodo retorna un dataframe con la data importada del archivo especificado
    """



def ImportDataFromPostgreSQL(tabla: str, columnas: list) -> pl.DataFrame:

    """
        este método permita extraer datos de la base datos Atenciones.

        Los parámetros indican cual es la tabla y el nombre de las columnas que se necesitan extraer.

        Recuerde que aquí se debe abrir una conexión para realizar la consulta de tipo select y al finalizar
        deberá cerrar la conexión.

        El método retornará un dataframe con la data extraída de la base de datos.

        Para concatenar los valores de la lista Columnas use el siguiente código:

        ', '.join(columnas)

    """